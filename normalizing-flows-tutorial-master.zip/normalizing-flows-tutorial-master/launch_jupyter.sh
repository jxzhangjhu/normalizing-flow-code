#!/bin/bash

jupyter notebook --no-browser --port 8889


